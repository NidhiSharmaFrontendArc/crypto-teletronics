import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Peeps! Nice to e-meet you !';
  imageSrcWall = 'assets/images/wallpaper.jpeg'  
  imageSrcFooter = 'assets/images/bye.png'  
  imageAltFooter = 'Bye'
  imageSrcHello = 'assets/images/hello-yellow.png'  
  imageAltHello = 'Hello'
}
